package squirrelGames.exceptions;

public class PorcentajeInvalidoException extends Exception {
   
	private static final long serialVersionUID = 1L;

	public PorcentajeInvalidoException(String mensaje) {
        super(mensaje);
    }
}
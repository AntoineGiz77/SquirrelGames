package squirrelGames.exceptions;

public class SupervisorInvalidoException extends Exception {

	private static final long serialVersionUID = 1L;

	public SupervisorInvalidoException(String mensaje) {
        super(mensaje);
    }
}
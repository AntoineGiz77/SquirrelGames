package squirrelGames.exceptions;

public class InfiltradoNoEliminableException extends Exception {
   
	private static final long serialVersionUID = 1L;

	public InfiltradoNoEliminableException(String mensaje) {
        super(mensaje);
    }
}
